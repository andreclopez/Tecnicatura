
// 41- Crea una variable llamada `nombre` y asígnale tu nombre. Luego, 
// muestra el valor de la variable en la consola.

console.log("----- EJ 41 ----- ")
let nombre = "Cristian"; 
console.log(nombre);

 

 // 42. Define una variable llamada `edad` y asígnale tu edad. 
 // Luego, muestra un mensaje que diga "Tienes X años" en la consola, 
 //reemplazando X con el valor de la variable.

 console.log("----- EJ 42 ----- ")

 let edad = 33;
 edad = 34;

 console.log("1- Tienes", edad , "años");
 console.log("2- Tienes" + " " + edad + " " + "años");
 console.log("3- Tienes " + edad + " años");
 console.log(`4- ${nombre} tiene ${edad} años. `);

// 43. Crea una variable llamada `esEstudiante` 
// y asígnale `true` si eres estudiante o `false` si no lo eres.
// Luego, muestra un mensaje que diga "Eres estudiante" o 
// "No eres estudiante" en la consola según el valor de la variable.

console.log("----- EJ 43 ----- ");

let esEstudiante = false;

if( esEstudiante == true  ) // esEstudiante == false
{
    // parte verdadera
    console.log("Es estudiante");
}
else{
     // parte falsa
     console.log("No es estudiante");
}

// 45. Define una variable llamada `numero1` 
// y otra llamada `numero2`. Realiza una operación 
// aritmética (suma, resta, multiplicación o división) 
// con estas variables y muestra el resultado en la consola.

console.log("----- EJ 45 ----- ");

let numero1 = 50;
let numero2 = 50;

let suma = numero1 + numero2;
let multiplicacion = numero1 * numero2;
let resta = numero1 - numero2;
let division = null;

console.log("suma es: ",  suma );
console.log("multiplicacion es: ",  multiplicacion );
console.log("resta es: ",  resta );

if( numero1 > numero2 )
{
    division = numero1 / numero2;
    console.log("division es num1 / num2: ",  division );
}else{

    // puedo tener 2 posibles resultados
    // 1- que el numero 2 sea mayor al 1

    if( numero2 > numero1 )
    {
        division = numero2 / numero1;
        console.log("division es num2 / num1: ",  division );
    }else{
        // los numeros son iguales
        division = numero2 / numero1;
        console.log("numeros iguales: ",  division );
    }
}

// 54. Define dos variables, `numero1` y `numero2`, 
// y realiza una comparación para determinar cuál de 
// los dos números es mayor. Luego, muestra el número mayor en la consola.

console.log( "----- EJ 54 ----- " );

let numero_1 = parseInt( "15" ) //prompt("ingrese el num1");
let numero_2 = parseFloat( "15.0" )   //prompt("ingrese el num2");

if( numero_2 > numero_1 ){
    // verdadera
    console.log("el num mayor es el 2, que tiene el valor: ", numero_2);
}else{

    // falsa     
    if(numero_1 == numero_2)
    {
        console.log("los numeros son iguales: ");

    }else{

        console.log("el num mayor es el 1, que tiene el valor: ", numero_1);
    }
    
}

// 55. Crea una variable llamada `color` y asígnale el
// nombre de un color. 
// Utiliza una serie de declaraciones 
// `if...else if` para determinar si el color
// es "Rojo," "Verde," o "Azul," y muestra un mensaje
// correspondiente en la consola.

console.log( "----- EJ 55 ----- " );

let color = "azul";

/* if( color == "rojo" ){
    console.log("El color es rojo")
} else if( color == "azul" ){
    console.log("El color es azul")
} else if( color == "verde" ){
    console.log("El color es verde")
} else {
    console.log("El color no existe");
} */

switch( color )
{
   case "rojo":
        console.log("El color es rojo");
        break;

    case "verde":
        console.log("El color es verde");
        break;

    case "azul":
        console.log("El color es azul");
        break;

    default:
        console.log("El color no existe");
        break;
}


// 58. Escribe una función llamada `esPar` 
//que tome un número como argumento y retorne `true` 
// si es par o `false` si es impar. Luego, muestra el 
// resultado en la consola.

console.log( "----- EJ 58 ----- " );

// globales
let num1 = 1;
let num2 = 2;

function esPar( n1 ){

    let divEntero = parseInt( n1 /2 );
    let divFloat =  parseFloat(n1 /2);

    
    // es par
     return true;

     // sea impar
     return false;

}

esPar( 6 );  
 


