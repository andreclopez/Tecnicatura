
// 41- Crea una variable llamada `nombre` y asígnale tu nombre. Luego, 
// muestra el valor de la variable en la consola.

console.log("----- EJ 41 ----- ")
let nombre = "Cristian"; 
console.log(nombre);

 

 // 42. Define una variable llamada `edad` y asígnale tu edad. 
 // Luego, muestra un mensaje que diga "Tienes X años" en la consola, 
 //reemplazando X con el valor de la variable.

 console.log("----- EJ 42 ----- ")

 let edad = 33;
 edad = 34;

 console.log("1- Tienes", edad , "años");
 console.log("2- Tienes" + " " + edad + " " + "años");
 console.log("3- Tienes " + edad + " años");
 console.log(`4- ${nombre} tiene ${edad} años. `);

// 43. Crea una variable llamada `esEstudiante` 
// y asígnale `true` si eres estudiante o `false` si no lo eres.
// Luego, muestra un mensaje que diga "Eres estudiante" o 
// "No eres estudiante" en la consola según el valor de la variable.

console.log("----- EJ 43 ----- ");

let esEstudiante = false;

if( esEstudiante == true  ) // esEstudiante == false
{
    // parte verdadera
    console.log("Es estudiante");
}
else{
     // parte falsa
     console.log("No es estudiante");
}

// 45. Define una variable llamada `numero1` 
// y otra llamada `numero2`. Realiza una operación 
// aritmética (suma, resta, multiplicación o división) 
// con estas variables y muestra el resultado en la consola.

console.log("----- EJ 45 ----- ");

let numero1 = 50;
let numero2 = 50;

let suma = numero1 + numero2;
let multiplicacion = numero1 * numero2;
let resta = numero1 - numero2;
let division = null;

console.log("suma es: ",  suma );
console.log("multiplicacion es: ",  multiplicacion );
console.log("resta es: ",  resta );

if( numero1 > numero2 )
{
    division = numero1 / numero2;
    console.log("division es num1 / num2: ",  division );
}else{

    // puedo tener 2 posibles resultados
    // 1- que el numero 2 sea mayor al 1

    if( numero2 > numero1 )
    {
        division = numero2 / numero1;
        console.log("division es num2 / num1: ",  division );
    }else{
        // los numeros son iguales
        division = numero2 / numero1;
        console.log("numeros iguales: ",  division );
    }
}





